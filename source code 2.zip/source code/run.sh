export CUDA_VISIBLE_DEVICES=1

#python test_fastdvdnet.py --test_path /media/micro-gesture/work/haoyu/gopro_540p/motorbike --noise_sigma 30 --save_path results

#python train_fastdvdnet.py --trainset_dir /media/micro-gesture/work/haoyu/Denois_sets/fastdvd/training/DAVIS-train-mp4/mp4_test --valset_dir /media/micro-gesture/work/haoyu/Denois_sets/fastdvd/testing/gopro_540p/ --log_dir logs --max_number_patches 2560 --epochs 1

python train_fastdvdnet_poisson.py --trainset_dir ./data/Training/Video_GT --valset_dir ./data/validating/ --log_dir logs --max_number_patches 2560 --milestone 25 30 --epochs 40

#python test_fastdvdnet_poisson_raw.py --test_path /media/micro-gesture/work/haoyu/Denois_sets/lung/validating/Validation/Validation/Reference/6/ --noise_sigma 50 --save_path results


#python test_fastdvdnet_poisson_raw.py --test_path /media/micro-gesture/work/haoyu/Denois_sets/lung/Testing/Testing_png/6/ --noise_sigma 50 --save_path result_raw/6
