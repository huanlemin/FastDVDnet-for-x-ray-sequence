import numpy as np
# import scipy.misc
import cv2
import os
import datetime


# home_dir = os.environ['HOME']
dir_root = 'C:\\Users\\yl18\\Desktop\\Five-frame Dataset\\Five-frame Dataset'
# dir_save = 'C:\\Users\\yl18\\Desktop\\Five-frame Dataset\\Five-frame Dataset'
# dir_test = "C:\\Users\\yl18\\Desktop\\Five-frame Dataset\\Five-frame Dataset\\Clean\\Sequence 1\\1\\2016051600000006_Frame1.png"


def get_folder_name(file_dir_):
    file_list = []
    for root, dirs, files in os.walk(file_dir_):
        if root.count('\\') == file_dir_.count('\\') + 1:
            file_list.append(root)
    file_list.sort()
    return file_list


def get_file_name(file_dir_):
    file_list = []
    for root, dirs, files in os.walk(file_dir_):
        # print(root)  # current path
        if root.count('\\') == file_dir_.count('\\'):
            for name in files:
                str = file_dir_ + '\\' + name
                file_list.append(str)
    file_list.sort()
    return file_list


def rename_sequence(file_dir_):
    # cnt_folder = 1
    for cnt_folder, root in enumerate(file_dir_):
        qian = str(cnt_folder//1000)
        bai = str(cnt_folder%1000//100)
        shi = str(cnt_folder%100//10)
        ge = str(cnt_folder%10)
        pos_name = root.find('Sequence')
        new_name = root[:pos_name] + 'Sequence_' + qian + bai + shi + ge
        os.rename(root, new_name)
        # cnt_folder += 1

def rename_sub_sequence(file_dir_):
    # cnt_folder = 1
    for cnt_folder, root in enumerate(file_dir_):
        qian = str(cnt_folder//1000)
        bai = str(cnt_folder%1000//100)
        shi = str(cnt_folder%100//10)
        ge = str(cnt_folder%10)
        pos_name = root.find('Sequence_')
        new_name = root[:pos_name+14] + qian + bai + shi + ge
        os.rename(root, new_name)
        # cnt_folder += 1


def read_sub_seq(lst_in, index=0):
    dir_sub_seq = get_folder_name(lst_in)
    dir_imgs = get_file_name(dir_sub_seq[index])
    lst_img = []
    for i, dir_img in enumerate(dir_imgs):
        lst_img.append(cv2.imread(dir_img, -1))
    return lst_img


def read_all_sub_seq(lst_in, dir_save=None):
    dir_sub_seq = get_folder_name(lst_in)
    # dir_imgs = get_file_name(dir_sub_seq[index])
    # lst_img = []
    for cnt_sub_seq, dir_imgs in enumerate(dir_sub_seq):
        lst_img_name = get_file_name(dir_imgs)
        curr_time = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:16]
        for i, name_img in enumerate(lst_img_name):
            name_save = dir_save + '\\' + str(curr_time) + '_F_' + str(i) + '.png'
            tmp_img = cv2.imread(name_img, -1)
            cv2.imwrite(name_save, tmp_img.astype(np.uint8), [cv2.IMWRITE_PNG_COMPRESSION, 0])
            print("save img: ", name_save)
    return True


def read_img(lst_in_c, lst_in_n, ind_seq=0, ind_sub_seq=0, flg_rand=True):
    rand_seq = int(np.random.rand() * 100000000000 % len(lst_in_c))
    if flg_rand:
        lst_sub_seq = get_folder_name(lst_in_c[rand_seq])
        rand_sub_seq = int(np.random.rand() * 100000000000 % len(lst_sub_seq))
        lst_img_c = read_sub_seq(lst_in_c[rand_seq], rand_sub_seq)
        lst_img_n = read_sub_seq(lst_in_n[rand_seq], rand_sub_seq)

    else:
        lst_img_c = read_sub_seq(lst_in_c[ind_seq], ind_sub_seq)
        lst_img_n = read_sub_seq(lst_in_n[ind_seq], ind_sub_seq)

    # print(lst_img_c[0].shape)
    # print(lst_in_c[rand_seq], rand_sub_seq)

    return lst_img_c, lst_img_n


def main():
    dir_root_n = dir_root + "\\Noise"
    dir_root_c = dir_root + "\\Clean"
    '''
    lst_dir_root_c = get_folder_name(dir_root_c)
    rename_sequence(lst_dir_root_c)
    lst_dir_root_c = get_folder_name(dir_root_c)
    for cnt_seq, dir in enumerate(lst_dir_root_c):
        dir_sub_seq = get_folder_name(dir)
        rename_sub_sequence(dir_sub_seq)

    lst_dir_root_n = get_folder_name(dir_root_n)
    rename_sequence(lst_dir_root_n)
    lst_dir_root_n = get_folder_name(dir_root_n)
    for cnt_seq, dir in enumerate(lst_dir_root_n):
        dir_sub_seq = get_folder_name(dir)
        rename_sub_sequence(dir_sub_seq)
    '''
    lst_dir_root_n = get_folder_name(dir_root_n)
    lst_dir_root_c = get_folder_name(dir_root_c)

    # rand_seq = int(np.random.rand() * 100000000000 % len(lst_dir_root_c))
    lst_img_c, lst_img_n = read_img(lst_dir_root_c, lst_dir_root_n)
    a = lst_img_c[2]
    b = np.array(lst_img_n)
    pass



if __name__ == '__main__':
    main()
